// Empty Component-preload.js to avoid 404 errors
// This file is intentionally left empty as we're not using preloading
sap.ui.predefine("emlatracker/csvupload/Component-preload", [], function() {
    "use strict";
    return {};
});